// solo comportamiento
const boton = document.querySelector('.boton');
boton.addEventListener('click', () => {
  alert('Hola desde main.js');
});
