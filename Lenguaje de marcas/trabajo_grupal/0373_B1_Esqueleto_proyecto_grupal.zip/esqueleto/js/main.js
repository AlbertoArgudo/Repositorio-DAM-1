// 0373 · Bloque 1 · Vacío a propósito.
// JavaScript se da en el segundo trimestre. No hace falta tocarlo.
